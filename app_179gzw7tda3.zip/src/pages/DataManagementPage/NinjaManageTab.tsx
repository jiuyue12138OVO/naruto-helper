import { useState } from 'react'
import { Plus, Pencil, Trash2, Swords } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useData } from '@/contexts/DataContext'
import { INinja } from '@/data/ninjas'
import { cn } from '@/lib/utils'

const TIER_OPTIONS = ['T0', 'T1', 'T2', 'T3']
const DIFFICULTY_OPTIONS = ['低', '中', '高', '极高']

const TIER_COLORS: Record<string, string> = {
  T0: 'bg-red-500/10 text-red-500 border-red-500/20',
  T1: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
  T2: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
  T3: 'bg-muted text-muted-foreground border-border/30',
}

const DEFAULT_IMG =
  '/spark/app/app_179gzw7tda3/runtime/api/v1/storage/object/bucket_aadkjiem3ncds_static/static%2Faadkjhce422ts_ve_miaoda'

interface FormData {
  name: string
  tier: INinja['tier']
  advantage: string
  difficulty: INinja['difficulty']
  imageUrl: string
}

const EMPTY_FORM: FormData = {
  name: '',
  tier: 'T2',
  advantage: '',
  difficulty: '中',
  imageUrl: '',
}

export default function NinjaManageTab() {
  const { ninjas, addNinja, updateNinja, deleteNinja } = useData()

  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState<FormData>(EMPTY_FORM)
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({})

  const [deleteId, setDeleteId] = useState<string | null>(null)

  function openAdd() {
    setEditingId(null)
    setForm(EMPTY_FORM)
    setErrors({})
    setDialogOpen(true)
  }

  function openEdit(ninja: INinja) {
    setEditingId(ninja.id)
    setForm({
      name: ninja.name,
      tier: ninja.tier,
      advantage: ninja.advantage,
      difficulty: ninja.difficulty,
      imageUrl: ninja.imageUrl || '',
    })
    setErrors({})
    setDialogOpen(true)
  }

  function validate(): boolean {
    const e: typeof errors = {}
    if (!form.name.trim()) e.name = '名称不能为空'
    if (!form.advantage.trim()) e.advantage = '核心优势不能为空'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  function handleSubmit() {
    if (!validate()) return
    const data: INinja = {
      id: editingId || Date.now().toString(),
      name: form.name.trim(),
      tier: form.tier,
      advantage: form.advantage.trim(),
      difficulty: form.difficulty,
      imageUrl: form.imageUrl.trim() || DEFAULT_IMG,
    }
    if (editingId) {
      updateNinja(editingId, data)
    } else {
      addNinja(data)
    }
    setDialogOpen(false)
  }

  function handleDelete() {
    if (deleteId) {
      deleteNinja(deleteId)
      setDeleteId(null)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">共 {ninjas.length} 位忍者</p>
        <Button size="sm" onClick={openAdd} className="gap-1.5">
          <Plus className="size-4" />
          新增忍者
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="w-full overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">名称</TableHead>
                  <TableHead className="whitespace-nowrap w-[80px]">T级</TableHead>
                  <TableHead className="whitespace-nowrap">核心优势</TableHead>
                  <TableHead className="whitespace-nowrap w-[80px]">操作难度</TableHead>
                  <TableHead className="whitespace-nowrap text-right w-[120px]">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {ninjas.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground py-12">
                      <Swords className="size-8 mx-auto mb-2 opacity-30" />
                      暂无忍者数据，点击"新增忍者"添加
                    </TableCell>
                  </TableRow>
                ) : (
                  ninjas.map((n) => (
                    <TableRow key={n.id}>
                      <TableCell className="font-medium">
                        <span className="block truncate max-w-[200px]">{n.name}</span>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={cn('text-xs font-bold', TIER_COLORS[n.tier])}
                        >
                          {n.tier}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span className="block truncate max-w-[200px] text-muted-foreground text-sm">
                          {n.advantage}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {n.difficulty}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8"
                            onClick={() => openEdit(n)}
                          >
                            <Pencil className="size-4" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={() => setDeleteId(n.id)}
                          >
                            <Trash2 className="size-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* 新增/编辑对话框 */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingId ? '编辑忍者' : '新增忍者'}</DialogTitle>
            <DialogDescription>
              {editingId ? '修改忍者信息后点击保存' : '填写忍者信息后点击添加'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="ninja-name">
                名称 <span className="text-destructive">*</span>
              </Label>
              <Input
                id="ninja-name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="如：秽土转生·解 宇智波斑"
              />
              {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>T级 <span className="text-destructive">*</span></Label>
                <Select
                  value={form.tier}
                  onValueChange={(v) => setForm({ ...form, tier: v as INinja['tier'] })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TIER_OPTIONS.map((t) => (
                      <SelectItem key={t} value={t}>
                        {t}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>操作难度 <span className="text-destructive">*</span></Label>
                <Select
                  value={form.difficulty}
                  onValueChange={(v) =>
                    setForm({ ...form, difficulty: v as INinja['difficulty'] })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {DIFFICULTY_OPTIONS.map((d) => (
                      <SelectItem key={d} value={d}>
                        {d}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="ninja-adv">
                核心优势 <span className="text-destructive">*</span>
              </Label>
              <Input
                id="ninja-adv"
                value={form.advantage}
                onChange={(e) => setForm({ ...form, advantage: e.target.value })}
                placeholder="如：全图压制+高机动性"
              />
              {errors.advantage && (
                <p className="text-xs text-destructive">{errors.advantage}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="ninja-img">图片URL（可选）</Label>
              <Input
                id="ninja-img"
                value={form.imageUrl}
                onChange={(e) => setForm({ ...form, imageUrl: e.target.value })}
                placeholder="留空使用默认图片"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={handleSubmit}>{editingId ? '保存' : '添加'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 删除确认 */}
      <AlertDialog open={!!deleteId} onOpenChange={(v) => !v && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除？</AlertDialogTitle>
            <AlertDialogDescription>
              删除后将无法恢复，确定要删除该忍者数据吗？
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>确认删除</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
