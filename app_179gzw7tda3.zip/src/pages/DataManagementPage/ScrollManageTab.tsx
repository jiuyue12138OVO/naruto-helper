import { useState } from 'react'
import { Plus, Pencil, Trash2, ScrollText } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useData } from '@/contexts/DataContext'
import { IScroll } from '@/data/scrolls'
import { cn } from '@/lib/utils'

const TIER_OPTIONS = ['T0', 'T1', 'T2']

const TIER_COLORS: Record<string, string> = {
  T0: 'bg-red-500/10 text-red-500 border-red-500/20',
  T1: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
  T2: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
}

const DEFAULT_IMG =
  '/spark/app/app_179gzw7tda3/runtime/api/v1/storage/object/bucket_aadkjiem3ncds_static/static%2Faadkjfzry4khw_ve_miaoda'

interface FormData {
  name: string
  tier: IScroll['tier']
  description: string
  cooldown: string
  scenario: string
  imageUrl: string
}

const EMPTY_FORM: FormData = {
  name: '',
  tier: 'T2',
  description: '',
  cooldown: '',
  scenario: '',
  imageUrl: '',
}

export default function ScrollManageTab() {
  const { scrolls, addScroll, updateScroll, deleteScroll } = useData()

  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState<FormData>(EMPTY_FORM)
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({})

  const [deleteId, setDeleteId] = useState<string | null>(null)

  function openAdd() {
    setEditingId(null)
    setForm(EMPTY_FORM)
    setErrors({})
    setDialogOpen(true)
  }

  function openEdit(scroll: IScroll) {
    setEditingId(scroll.id)
    setForm({
      name: scroll.name,
      tier: scroll.tier,
      description: scroll.description,
      cooldown: scroll.cooldown,
      scenario: scroll.scenario,
      imageUrl: scroll.imageUrl || '',
    })
    setErrors({})
    setDialogOpen(true)
  }

  function validate(): boolean {
    const e: typeof errors = {}
    if (!form.name.trim()) e.name = '名称不能为空'
    if (!form.description.trim()) e.description = '效果描述不能为空'
    if (!form.cooldown.trim()) e.cooldown = '冷却时间不能为空'
    if (!form.scenario.trim()) e.scenario = '适用场景不能为空'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  function handleSubmit() {
    if (!validate()) return
    const data: IScroll = {
      id: editingId || Date.now().toString(),
      name: form.name.trim(),
      tier: form.tier,
      description: form.description.trim(),
      cooldown: form.cooldown.trim(),
      scenario: form.scenario.trim(),
      imageUrl: form.imageUrl.trim() || DEFAULT_IMG,
    }
    if (editingId) {
      updateScroll(editingId, data)
    } else {
      addScroll(data)
    }
    setDialogOpen(false)
  }

  function handleDelete() {
    if (deleteId) {
      deleteScroll(deleteId)
      setDeleteId(null)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">共 {scrolls.length} 个密卷</p>
        <Button size="sm" onClick={openAdd} className="gap-1.5">
          <Plus className="size-4" />
          新增密卷
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="w-full overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">名称</TableHead>
                  <TableHead className="whitespace-nowrap w-[80px]">T级</TableHead>
                  <TableHead className="whitespace-nowrap">效果描述</TableHead>
                  <TableHead className="whitespace-nowrap w-[90px]">冷却时间</TableHead>
                  <TableHead className="whitespace-nowrap">适用场景</TableHead>
                  <TableHead className="whitespace-nowrap text-right w-[120px]">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {scrolls.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-12">
                      <ScrollText className="size-8 mx-auto mb-2 opacity-30" />
                      暂无密卷数据，点击"新增密卷"添加
                    </TableCell>
                  </TableRow>
                ) : (
                  scrolls.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell className="font-medium">
                        <span className="block truncate max-w-[180px]">{s.name}</span>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={cn('text-xs font-bold', TIER_COLORS[s.tier])}
                        >
                          {s.tier}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span className="block truncate max-w-[180px] text-muted-foreground text-sm">
                          {s.description}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground whitespace-nowrap">
                        {s.cooldown}
                      </TableCell>
                      <TableCell>
                        <span className="block truncate max-w-[150px] text-muted-foreground text-sm">
                          {s.scenario}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8"
                            onClick={() => openEdit(s)}
                          >
                            <Pencil className="size-4" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={() => setDeleteId(s.id)}
                          >
                            <Trash2 className="size-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* 新增/编辑对话框 */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingId ? '编辑密卷' : '新增密卷'}</DialogTitle>
            <DialogDescription>
              {editingId ? '修改密卷信息后点击保存' : '填写密卷信息后点击添加'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="scroll-name">
                名称 <span className="text-destructive">*</span>
              </Label>
              <Input
                id="scroll-name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="如：风遁·风沙阵"
              />
              {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
            </div>
            <div className="space-y-2">
              <Label>T级 <span className="text-destructive">*</span></Label>
              <Select
                value={form.tier}
                onValueChange={(v) => setForm({ ...form, tier: v as IScroll['tier'] })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TIER_OPTIONS.map((t) => (
                    <SelectItem key={t} value={t}>
                      {t}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="scroll-desc">
                效果描述 <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="scroll-desc"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="如：大范围吸附，限制走位提升命中率"
                rows={2}
              />
              {errors.description && (
                <p className="text-xs text-destructive">{errors.description}</p>
              )}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="scroll-cd">
                  冷却时间 <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="scroll-cd"
                  value={form.cooldown}
                  onChange={(e) => setForm({ ...form, cooldown: e.target.value })}
                  placeholder="如：约15秒"
                />
                {errors.cooldown && (
                  <p className="text-xs text-destructive">{errors.cooldown}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="scroll-scenario">
                  适用场景 <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="scroll-scenario"
                  value={form.scenario}
                  onChange={(e) => setForm({ ...form, scenario: e.target.value })}
                  placeholder="如：远程消耗型忍者"
                />
                {errors.scenario && (
                  <p className="text-xs text-destructive">{errors.scenario}</p>
                )}
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="scroll-img">图片URL（可选）</Label>
              <Input
                id="scroll-img"
                value={form.imageUrl}
                onChange={(e) => setForm({ ...form, imageUrl: e.target.value })}
                placeholder="留空使用默认图片"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={handleSubmit}>{editingId ? '保存' : '添加'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 删除确认 */}
      <AlertDialog open={!!deleteId} onOpenChange={(v) => !v && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除？</AlertDialogTitle>
            <AlertDialogDescription>
              删除后将无法恢复，确定要删除该密卷数据吗？
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>确认删除</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
