import { useState } from 'react'
import { Plus, Pencil, Trash2, Link2, Star } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useData } from '@/contexts/DataContext'
import { IRecommendation } from '@/data/recommendations'

interface FormData {
  ninjaName: string
  scrollName: string
  reason: string
  rating: number
}

const EMPTY_FORM: FormData = {
  ninjaName: '',
  scrollName: '',
  reason: '',
  rating: 4,
}

export default function RecommendationManageTab() {
  const {
    ninjas,
    scrolls,
    recommendations,
    addRecommendation,
    updateRecommendation,
    deleteRecommendation,
  } = useData()

  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState<FormData>(EMPTY_FORM)
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({})

  const [deleteId, setDeleteId] = useState<string | null>(null)

  function openAdd() {
    setEditingId(null)
    setForm(EMPTY_FORM)
    setErrors({})
    setDialogOpen(true)
  }

  function openEdit(rec: IRecommendation) {
    setEditingId(rec.id)
    setForm({
      ninjaName: rec.ninjaName,
      scrollName: rec.scrollName,
      reason: rec.reason,
      rating: rec.rating,
    })
    setErrors({})
    setDialogOpen(true)
  }

  function validate(): boolean {
    const e: typeof errors = {}
    if (!form.ninjaName) e.ninjaName = '请选择忍者'
    if (!form.scrollName) e.scrollName = '请选择密卷'
    if (!form.reason.trim()) e.reason = '推荐理由不能为空'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  function handleSubmit() {
    if (!validate()) return
    const data: IRecommendation = {
      id: editingId || Date.now().toString(),
      ninjaName: form.ninjaName,
      scrollName: form.scrollName,
      reason: form.reason.trim(),
      rating: form.rating,
    }
    if (editingId) {
      updateRecommendation(editingId, data)
    } else {
      addRecommendation(data)
    }
    setDialogOpen(false)
  }

  function handleDelete() {
    if (deleteId) {
      deleteRecommendation(deleteId)
      setDeleteId(null)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">共 {recommendations.length} 条推荐</p>
        <Button size="sm" onClick={openAdd} className="gap-1.5">
          <Plus className="size-4" />
          新增推荐
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="w-full overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">忍者名称</TableHead>
                  <TableHead className="whitespace-nowrap">推荐密卷</TableHead>
                  <TableHead className="whitespace-nowrap">推荐理由</TableHead>
                  <TableHead className="whitespace-nowrap w-[100px]">适配度</TableHead>
                  <TableHead className="whitespace-nowrap text-right w-[120px]">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recommendations.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground py-12">
                      <Link2 className="size-8 mx-auto mb-2 opacity-30" />
                      暂无推荐数据，点击"新增推荐"添加
                    </TableCell>
                  </TableRow>
                ) : (
                  recommendations.map((r) => (
                    <TableRow key={r.id}>
                      <TableCell className="font-medium">
                        <span className="block truncate max-w-[160px]">{r.ninjaName}</span>
                      </TableCell>
                      <TableCell>
                        <span className="block truncate max-w-[160px] text-sm">
                          {r.scrollName}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className="block truncate max-w-[200px] text-muted-foreground text-sm">
                          {r.reason}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-0.5">
                          {Array.from({ length: 5 }).map((_, j) => (
                            <Star
                              key={j}
                              className={`size-3.5 ${
                                j < r.rating
                                  ? 'fill-amber-500 text-amber-500'
                                  : 'text-muted-foreground/30'
                              }`}
                            />
                          ))}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8"
                            onClick={() => openEdit(r)}
                          >
                            <Pencil className="size-4" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={() => setDeleteId(r.id)}
                          >
                            <Trash2 className="size-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* 新增/编辑对话框 */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingId ? '编辑推荐搭配' : '新增推荐搭配'}</DialogTitle>
            <DialogDescription>
              {editingId ? '修改推荐信息后点击保存' : '选择忍者和密卷后点击添加'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>
                忍者名称 <span className="text-destructive">*</span>
              </Label>
              <Select
                value={form.ninjaName}
                onValueChange={(v) => setForm({ ...form, ninjaName: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择忍者" />
                </SelectTrigger>
                <SelectContent>
                  {ninjas.map((n) => (
                    <SelectItem key={n.id} value={n.name}>
                      {n.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.ninjaName && (
                <p className="text-xs text-destructive">{errors.ninjaName}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label>
                密卷名称 <span className="text-destructive">*</span>
              </Label>
              <Select
                value={form.scrollName}
                onValueChange={(v) => setForm({ ...form, scrollName: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择密卷" />
                </SelectTrigger>
                <SelectContent>
                  {scrolls.map((s) => (
                    <SelectItem key={s.id} value={s.name}>
                      {s.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.scrollName && (
                <p className="text-xs text-destructive">{errors.scrollName}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="rec-reason">
                推荐理由 <span className="text-destructive">*</span>
              </Label>
              <Input
                id="rec-reason"
                value={form.reason}
                onChange={(e) => setForm({ ...form, reason: e.target.value })}
                placeholder="如：配合虚化反打，效果极佳"
              />
              {errors.reason && <p className="text-xs text-destructive">{errors.reason}</p>}
            </div>
            <div className="space-y-2">
              <Label>适配度评分</Label>
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setForm({ ...form, rating: star })}
                    className="p-0.5"
                  >
                    <Star
                      className={`size-6 transition-colors ${
                        star <= form.rating
                          ? 'fill-amber-500 text-amber-500'
                          : 'text-muted-foreground/30 hover:text-amber-500/50'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={handleSubmit}>{editingId ? '保存' : '添加'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 删除确认 */}
      <AlertDialog open={!!deleteId} onOpenChange={(v) => !v && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除？</AlertDialogTitle>
            <AlertDialogDescription>
              删除后将无法恢复，确定要删除该推荐搭配吗？
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>确认删除</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
