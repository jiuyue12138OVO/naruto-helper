import { motion } from 'framer-motion'
import { ArrowRight } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Image } from '@/components/ui/image';

const HERO_IMG = '/spark/app/app_179gzw7tda3/runtime/api/v1/storage/object/bucket_aadkjiem3ncds_static/static%2Faadkjhavgtkds_ve_miaoda'

export default function HeroSection() {
  const navigate = useNavigate()

  return (
    <section className="w-full relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src={HERO_IMG}
          alt="火影忍者"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/40 to-background" />
      </div>

      {/* Content */}
      <div className="relative max-w-7xl mx-auto px-4 md:px-6 py-20 md:py-32">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="text-center max-w-2xl mx-auto"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-6"
          >
            <span className="size-1.5 rounded-full bg-primary animate-pulse" />
            火影忍者手游辅助工具
          </motion.div>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight mb-4">
            忍者<span className="text-primary">助手</span>
          </h1>
          <p className="text-lg text-muted-foreground mb-8 max-w-lg mx-auto">
            一站式忍者强度排行、密卷推荐搭配，助你制霸决斗场
          </p>

          <div className="flex items-center justify-center gap-3">
            <Button
              size="lg"
              className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white border-0 shadow-lg shadow-orange-500/25"
              onClick={() => navigate('/tier-list')}
            >
              查看强度排行
              <ArrowRight className="size-4" />
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={() => navigate('/ninja-scroll')}
            >
              密卷推荐
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
