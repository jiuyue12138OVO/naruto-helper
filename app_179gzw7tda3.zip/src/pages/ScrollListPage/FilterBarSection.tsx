import { Search, X } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const TIERS = [
  { value: 'all', label: '全部' },
  { value: 'T0', label: 'T0 · 顶级密卷' },
  { value: 'T1', label: 'T1 · 强力密卷' },
  { value: 'T2', label: 'T2 · 可用密卷' },
]

interface FilterBarSectionProps {
  activeTier: string
  onTierChange: (tier: string) => void
  keyword: string
  onKeywordChange: (keyword: string) => void
}

export default function FilterBarSection({
  activeTier,
  onTierChange,
  keyword,
  onKeywordChange,
}: FilterBarSectionProps) {
  return (
    <div className="space-y-4">
      {/* Tier Filter Tabs */}
      <div className="flex flex-wrap gap-2">
        {TIERS.map((tier) => (
          <Button
            key={tier.value}
            variant={activeTier === tier.value ? 'default' : 'outline'}
            size="sm"
            onClick={() => onTierChange(tier.value)}
            className={cn(
              'rounded-full text-xs font-medium transition-all',
              activeTier === tier.value
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'border-border/50 text-muted-foreground hover:text-foreground hover:border-border'
            )}
          >
            {tier.label}
          </Button>
        ))}
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          type="search"
          value={keyword}
          onChange={(e) => onKeywordChange(e.target.value)}
          placeholder="搜索密卷名称..."
          className="bg-background pl-9 pr-9"
        />
        {keyword && (
          <Button
            size="icon"
            variant="ghost"
            className="!absolute right-1.5 top-1/2 z-20 h-7 w-7 -translate-y-1/2"
            onClick={() => onKeywordChange('')}
            aria-label="清除"
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>
    </div>
  )
}
