import { motion } from 'framer-motion'
import { Clock, Target, ScrollText } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { IScroll } from '@/data/scrolls'
import { cn } from '@/lib/utils'
import { Image } from '@/components/ui/image';

interface ScrollGridSectionProps {
  scrolls: IScroll[]
}

const TIER_COLORS: Record<string, string> = {
  T0: 'bg-red-500/10 text-red-500 border-red-500/20',
  T1: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
  T2: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
}

export default function ScrollGridSection({ scrolls }: ScrollGridSectionProps) {
  if (scrolls.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
        <ScrollText className="size-12 mb-4 opacity-30" />
        <p className="text-lg">没有找到匹配的密卷</p>
        <p className="text-sm">试试调整筛选条件</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {scrolls.map((scroll, i) => (
        <motion.div
          key={scroll.id}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, delay: i * 0.06 }}
          whileHover={{ y: -4, transition: { duration: 0.2 } }}
        >
          <Card className="overflow-hidden border-border/40 bg-card/50 hover:bg-card/80 transition-colors h-full group">
            {/* Image */}
            <div className="relative aspect-[4/3] overflow-hidden">
              <Image
                src={scroll.imageUrl}
                alt={scroll.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-card via-card/20 to-transparent" />
              <Badge
                variant="outline"
                className={cn(
                  'absolute top-3 right-3 text-xs font-bold',
                  TIER_COLORS[scroll.tier]
                )}
              >
                {scroll.tier}
              </Badge>
            </div>

            <CardContent className="p-4 space-y-3">
              <h3 className="font-bold text-foreground">{scroll.name}</h3>

              <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2">
                {scroll.description}
              </p>

              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Clock className="size-3 shrink-0" />
                  <span>{scroll.cooldown}</span>
                </div>
                <div className="flex items-center gap-1 min-w-0">
                  <Target className="size-3 shrink-0" />
                  <span className="truncate">{scroll.scenario}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}
