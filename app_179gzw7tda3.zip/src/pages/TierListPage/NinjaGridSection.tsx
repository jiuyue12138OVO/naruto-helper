import { motion } from 'framer-motion'
import { Swords, Gauge } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { INinja } from '@/data/ninjas'
import { cn } from '@/lib/utils'
import { Image } from '@/components/ui/image';

interface NinjaGridSectionProps {
  ninjas: INinja[]
}

const TIER_COLORS: Record<string, string> = {
  T0: 'bg-red-500/10 text-red-500 border-red-500/20',
  T1: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
  T2: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
  T3: 'bg-muted text-muted-foreground border-border/30',
}

const TIER_LABELS: Record<string, string> = {
  T0: '版本天花板',
  T1: '强势忍者',
  T2: '中规中矩',
  T3: '待开发',
}

const DIFFICULTY_COLORS: Record<string, string> = {
  '极高': 'text-red-400',
  '高': 'text-orange-400',
  '中': 'text-amber-400',
  '低': 'text-green-400',
}

export default function NinjaGridSection({ ninjas }: NinjaGridSectionProps) {
  const grouped = ninjas.reduce<Record<string, INinja[]>>((acc, n) => {
    if (!acc[n.tier]) acc[n.tier] = []
    acc[n.tier].push(n)
    return acc
  }, {})

  const tierOrder = ['T0', 'T1', 'T2', 'T3']

  if (ninjas.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
        <Swords className="size-12 mb-4 opacity-30" />
        <p className="text-lg">没有找到匹配的忍者</p>
        <p className="text-sm">试试调整筛选条件</p>
      </div>
    )
  }

  return (
    <div className="space-y-10">
      {tierOrder.map((tier) => {
        const list = grouped[tier]
        if (!list || list.length === 0) return null

        return (
          <div key={tier}>
            {/* Tier Header */}
            <div className="flex items-center gap-3 mb-4">
              <Badge
                variant="outline"
                className={cn('text-sm font-bold px-3 py-1', TIER_COLORS[tier])}
              >
                {tier}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {TIER_LABELS[tier]} · {list.length} 位忍者
              </span>
            </div>

            {/* Ninja Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {list.map((ninja, i) => (
                <motion.div
                  key={ninja.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.05 }}
                  whileHover={{ y: -4, transition: { duration: 0.2 } }}
                >
                  <Card className="overflow-hidden border-border/40 bg-card/50 hover:bg-card/80 transition-colors h-full group">
                    {/* Image */}
                    <div className="relative aspect-[4/3] overflow-hidden">
                      <Image
                        src={ninja.imageUrl}
                        alt={ninja.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-card via-card/20 to-transparent" />
                      <Badge
                        variant="outline"
                        className={cn(
                          'absolute top-3 right-3 text-xs font-bold',
                          TIER_COLORS[ninja.tier]
                        )}
                      >
                        {ninja.tier}
                      </Badge>
                    </div>

                    <CardContent className="p-4 space-y-3">
                      <h3 className="font-bold text-foreground truncate">{ninja.name}</h3>

                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Swords className="size-3 shrink-0" />
                        <span className="truncate">{ninja.advantage}</span>
                      </div>

                      <div className="flex items-center gap-1.5 text-xs">
                        <Gauge className="size-3 shrink-0" />
                        <span className={DIFFICULTY_COLORS[ninja.difficulty]}>
                          操作难度: {ninja.difficulty}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        )
      })}
    </div>
  )
}
