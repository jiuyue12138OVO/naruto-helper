import { useState, useMemo } from 'react'
import FilterBarSection from './FilterBarSection'
import NinjaGridSection from './NinjaGridSection'
import { useData } from '@/contexts/DataContext'

export default function TierListPage() {
  const { ninjas } = useData()
  const [activeTier, setActiveTier] = useState('all')
  const [keyword, setKeyword] = useState('')

  const filtered = useMemo(() => {
    return ninjas.filter((n) => {
      const matchTier = activeTier === 'all' || n.tier === activeTier
      const matchKeyword =
        !keyword || n.name.toLowerCase().includes(keyword.toLowerCase())
      return matchTier && matchKeyword
    })
  }, [ninjas, activeTier, keyword])

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-12 space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-1">
            忍者<span className="text-primary">强度排行</span>
          </h1>
          <p className="text-muted-foreground text-sm">按T级分类，助你了解版本格局</p>
        </div>

        <FilterBarSection
          activeTier={activeTier}
          onTierChange={setActiveTier}
          keyword={keyword}
          onKeywordChange={setKeyword}
        />

        <NinjaGridSection ninjas={filtered} />
      </div>
    </div>
  )
}
