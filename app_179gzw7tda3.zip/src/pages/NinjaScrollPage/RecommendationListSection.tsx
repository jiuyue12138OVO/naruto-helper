import { motion } from 'framer-motion'
import { Star, ScrollText, User } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { IRecommendation } from '@/data/recommendations'

interface RecommendationListSectionProps {
  recommendations: IRecommendation[]
}

export default function RecommendationListSection({
  recommendations,
}: RecommendationListSectionProps) {
  if (recommendations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
        <ScrollText className="size-12 mb-4 opacity-30" />
        <p className="text-lg">没有找到匹配的推荐</p>
        <p className="text-sm">试试搜索其他忍者名称</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {recommendations.map((rec, i) => (
        <motion.div
          key={rec.id}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, delay: i * 0.08 }}
          whileHover={{ y: -3, transition: { duration: 0.2 } }}
        >
          <Card className="border-border/40 bg-card/50 hover:bg-card/80 transition-colors h-full">
            <CardContent className="p-5 space-y-4">
              {/* Ninja + Scroll */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0 space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="size-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <User className="size-4 text-primary" />
                    </div>
                    <h3 className="font-bold text-foreground truncate">{rec.ninjaName}</h3>
                  </div>

                  <div className="flex items-center gap-2 pl-10">
                    <ScrollText className="size-3.5 text-muted-foreground shrink-0" />
                    <Badge variant="secondary" className="text-xs font-medium">
                      {rec.scrollName}
                    </Badge>
                  </div>
                </div>

                {/* Rating */}
                <div className="flex items-center gap-0.5 shrink-0">
                  {Array.from({ length: 5 }).map((_, j) => (
                    <Star
                      key={j}
                      className={`size-4 ${
                        j < rec.rating
                          ? 'fill-amber-500 text-amber-500'
                          : 'text-muted-foreground/30'
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Reason */}
              <div className="pl-10">
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {rec.reason}
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}
