import { useState, useMemo } from 'react'
import SearchBarSection from './SearchBarSection'
import RecommendationListSection from './RecommendationListSection'
import { useData } from '@/contexts/DataContext'

export default function NinjaScrollPage() {
  const { recommendations } = useData()
  const [keyword, setKeyword] = useState('')

  const filtered = useMemo(() => {
    if (!keyword) return recommendations
    return recommendations.filter((r) =>
      r.ninjaName.toLowerCase().includes(keyword.toLowerCase())
    )
  }, [recommendations, keyword])

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-12 space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-1">
            忍者<span className="text-primary">密卷推荐</span>
          </h1>
          <p className="text-muted-foreground text-sm">查看各忍者最佳密卷搭配方案</p>
        </div>

        <SearchBarSection keyword={keyword} onKeywordChange={setKeyword} />

        <RecommendationListSection recommendations={filtered} />
      </div>
    </div>
  )
}
