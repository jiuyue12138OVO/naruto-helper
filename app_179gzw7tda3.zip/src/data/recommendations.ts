// EXPORTS: IRecommendation, MOCK_RECOMMENDATIONS
export interface IRecommendation {
  id: string
  ninjaName: string
  scrollName: string
  reason: string
  rating: number // 适配度评分 1-5
}

export const MOCK_RECOMMENDATIONS: IRecommendation[] = [
  {
    id: '1',
    ninjaName: '漂泊带土',
    scrollName: '冰遁·冻雪',
    reason: '配合虚化反打，效果极佳',
    rating: 5
  },
  {
    id: '2',
    ninjaName: '须佐能乎鼬',
    scrollName: '风遁·风沙阵',
    reason: '提升技能命中率',
    rating: 5
  },
  {
    id: '3',
    ninjaName: '死门凯',
    scrollName: '雷遁·雷电击',
    reason: '先手起手快，节奏适配',
    rating: 4
  },
  {
    id: '4',
    ninjaName: '秽土再不斩',
    scrollName: '水遁·水冲波',
    reason: '配合隐身机制，雾隐巅峰',
    rating: 4
  },
  {
    id: '5',
    ninjaName: '白面具带土',
    scrollName: '忍体术·反',
    reason: '宇智波反弹专属效果',
    rating: 5
  },
  {
    id: '6',
    ninjaName: '秽土转生·解 宇智波斑',
    scrollName: '忍体术·御',
    reason: '专属密卷效果，攻防兼备',
    rating: 5
  },
  {
    id: '7',
    ninjaName: '金身水门',
    scrollName: '水遁·水冲波',
    reason: '配合机动性拉扯，无敌帧衔接',
    rating: 4
  }
]
