// EXPORTS: INinja, MOCK_NINJAS
export interface INinja {
  id: string
  name: string
  tier: 'T0' | 'T1' | 'T2' | 'T3'
  advantage: string
  difficulty: '低' | '中' | '高' | '极高'
  imageUrl: string
}

const NINJA_IMG_1 = '/spark/app/app_179gzw7tda3/runtime/api/v1/storage/object/bucket_aadkjiem3ncds_static/static%2Faadkjhce422ts_ve_miaoda'
const NINJA_IMG_2 = '/spark/app/app_179gzw7tda3/runtime/api/v1/storage/object/bucket_aadkjiem3ncds_static/static%2Faadkjhjtuakgw_ve_miaoda'
const NINJA_IMG_3 = '/spark/app/app_179gzw7tda3/runtime/api/v1/storage/object/bucket_aadkjiem3ncds_static/static%2Faadkjg4nwswbu_ve_miaoda'

export const MOCK_NINJAS: INinja[] = [
  {
    id: '1',
    name: '秽土转生·解 宇智波斑',
    tier: 'T0',
    advantage: '全图压制+高机动性，胜率56.86%',
    difficulty: '极高',
    imageUrl: NINJA_IMG_1
  },
  {
    id: '2',
    name: '十尾人柱力 宇智波带土',
    tier: 'T0',
    advantage: '双形态切换，爆发与续航兼备',
    difficulty: '极高',
    imageUrl: NINJA_IMG_2
  },
  {
    id: '3',
    name: '死门凯',
    tier: 'T0',
    advantage: '节奏快伤害高，八门遁甲独特',
    difficulty: '高',
    imageUrl: NINJA_IMG_3
  },
  {
    id: '4',
    name: '五影会谈斑',
    tier: 'T0',
    advantage: '全图压制，须佐能乎攻防一体',
    difficulty: '高',
    imageUrl: NINJA_IMG_1
  },
  {
    id: '5',
    name: '金身水门',
    tier: 'T0',
    advantage: '机动性天花板，飞雷神拉扯极强',
    difficulty: '极高',
    imageUrl: NINJA_IMG_2
  },
  {
    id: '6',
    name: '漂泊带土',
    tier: 'T0',
    advantage: '火龙卷起手，虚化反打',
    difficulty: '高',
    imageUrl: NINJA_IMG_3
  },
  {
    id: '7',
    name: '须佐能乎鼬',
    tier: 'T0',
    advantage: '八坂勾玉+十拳剑连招伤害极高',
    difficulty: '高',
    imageUrl: NINJA_IMG_1
  },
  {
    id: '8',
    name: '双神威卡卡西',
    tier: 'T0',
    advantage: '神威空间机制，攻防转换灵活',
    difficulty: '高',
    imageUrl: NINJA_IMG_2
  },
  {
    id: '9',
    name: '白面具带土',
    tier: 'T1',
    advantage: '虚化机制优秀，反手能力强',
    difficulty: '中',
    imageUrl: NINJA_IMG_3
  },
  {
    id: '10',
    name: '须佐卡卡西',
    tier: 'T1',
    advantage: '须佐能乎防御+高爆发',
    difficulty: '中',
    imageUrl: NINJA_IMG_1
  },
  {
    id: '11',
    name: '长门',
    tier: 'T1',
    advantage: '佩恩六道技能多样，控制链完整',
    difficulty: '中',
    imageUrl: NINJA_IMG_2
  },
  {
    id: '12',
    name: '初代火影',
    tier: 'T1',
    advantage: '木遁大范围压制，血量厚',
    difficulty: '中',
    imageUrl: NINJA_IMG_3
  },
  {
    id: '13',
    name: '新春大蛇丸',
    tier: 'T1',
    advantage: '无缝霸体，新增空中释放',
    difficulty: '中',
    imageUrl: NINJA_IMG_1
  },
  {
    id: '14',
    name: '秽土再不斩',
    tier: 'T1',
    advantage: '隐身封堵能力强，雾隐巅峰',
    difficulty: '高',
    imageUrl: NINJA_IMG_2
  },
  {
    id: '15',
    name: '晓大蛇丸',
    tier: 'T1',
    advantage: '罗生门远程起手+减伤减CD',
    difficulty: '中',
    imageUrl: NINJA_IMG_3
  },
  {
    id: '16',
    name: '侠隐江湖药师兜',
    tier: 'T1',
    advantage: '超远普攻+Y/X轴起手组合',
    difficulty: '高',
    imageUrl: NINJA_IMG_1
  },
  {
    id: '17',
    name: '活水门',
    tier: 'T2',
    advantage: '机动性不错',
    difficulty: '中',
    imageUrl: NINJA_IMG_2
  },
  {
    id: '18',
    name: '四代雷影',
    tier: 'T2',
    advantage: '雷遁铠甲机制，爆发尚可',
    difficulty: '中',
    imageUrl: NINJA_IMG_3
  },
  {
    id: '19',
    name: '忍战我爱罗',
    tier: 'T2',
    advantage: '沙遁大范围控制',
    difficulty: '低',
    imageUrl: NINJA_IMG_1
  },
  {
    id: '20',
    name: '百豪樱',
    tier: 'T2',
    advantage: '百豪之术回血，近战爆发',
    difficulty: '低',
    imageUrl: NINJA_IMG_2
  }
]
