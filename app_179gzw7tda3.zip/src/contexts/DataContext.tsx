import { createContext, useContext, useState, useCallback, type ReactNode } from 'react'
import { scopedStorage } from '@lark-apaas/client-toolkit-lite'
import { INinja, MOCK_NINJAS } from '@/data/ninjas'
import { IScroll, MOCK_SCROLLS } from '@/data/scrolls'
import { IRecommendation, MOCK_RECOMMENDATIONS } from '@/data/recommendations'

const NINJAS_KEY = 'naruto_ninjas'
const SCROLLS_KEY = 'naruto_scrolls'
const RECS_KEY = 'naruto_recommendations'

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = scopedStorage.getItem(key)
    if (raw) return JSON.parse(raw) as T
  } catch { /* localStorage 不可用时降级 */ }
  return fallback
}

function saveToStorage(key: string, data: unknown) {
  try {
    scopedStorage.setItem(key, JSON.stringify(data))
  } catch { /* 静默失败 */ }
}

interface DataContextType {
  ninjas: INinja[]
  scrolls: IScroll[]
  recommendations: IRecommendation[]
  addNinja: (ninja: INinja) => void
  updateNinja: (id: string, data: Partial<INinja>) => void
  deleteNinja: (id: string) => void
  addScroll: (scroll: IScroll) => void
  updateScroll: (id: string, data: Partial<IScroll>) => void
  deleteScroll: (id: string) => void
  addRecommendation: (rec: IRecommendation) => void
  updateRecommendation: (id: string, data: Partial<IRecommendation>) => void
  deleteRecommendation: (id: string) => void
  resetAllData: () => void
}

const DataContext = createContext<DataContextType | null>(null)

export function DataProvider({ children }: { children: ReactNode }) {
  const [ninjas, setNinjas] = useState<INinja[]>(() =>
    loadFromStorage(NINJAS_KEY, MOCK_NINJAS)
  )
  const [scrolls, setScrolls] = useState<IScroll[]>(() =>
    loadFromStorage(SCROLLS_KEY, MOCK_SCROLLS)
  )
  const [recommendations, setRecommendations] = useState<IRecommendation[]>(() =>
    loadFromStorage(RECS_KEY, MOCK_RECOMMENDATIONS)
  )

  // --- Ninja CRUD ---
  const addNinja = useCallback((ninja: INinja) => {
    setNinjas((prev) => {
      const next = [...prev, ninja]
      saveToStorage(NINJAS_KEY, next)
      return next
    })
  }, [])

  const updateNinja = useCallback((id: string, data: Partial<INinja>) => {
    setNinjas((prev) => {
      const next = prev.map((n) => (n.id === id ? { ...n, ...data } : n))
      saveToStorage(NINJAS_KEY, next)
      return next
    })
  }, [])

  const deleteNinja = useCallback((id: string) => {
    setNinjas((prev) => {
      const next = prev.filter((n) => n.id !== id)
      saveToStorage(NINJAS_KEY, next)
      return next
    })
  }, [])

  // --- Scroll CRUD ---
  const addScroll = useCallback((scroll: IScroll) => {
    setScrolls((prev) => {
      const next = [...prev, scroll]
      saveToStorage(SCROLLS_KEY, next)
      return next
    })
  }, [])

  const updateScroll = useCallback((id: string, data: Partial<IScroll>) => {
    setScrolls((prev) => {
      const next = prev.map((s) => (s.id === id ? { ...s, ...data } : s))
      saveToStorage(SCROLLS_KEY, next)
      return next
    })
  }, [])

  const deleteScroll = useCallback((id: string) => {
    setScrolls((prev) => {
      const next = prev.filter((s) => s.id !== id)
      saveToStorage(SCROLLS_KEY, next)
      return next
    })
  }, [])

  // --- Recommendation CRUD ---
  const addRecommendation = useCallback((rec: IRecommendation) => {
    setRecommendations((prev) => {
      const next = [...prev, rec]
      saveToStorage(RECS_KEY, next)
      return next
    })
  }, [])

  const updateRecommendation = useCallback((id: string, data: Partial<IRecommendation>) => {
    setRecommendations((prev) => {
      const next = prev.map((r) => (r.id === id ? { ...r, ...data } : r))
      saveToStorage(RECS_KEY, next)
      return next
    })
  }, [])

  const deleteRecommendation = useCallback((id: string) => {
    setRecommendations((prev) => {
      const next = prev.filter((r) => r.id !== id)
      saveToStorage(RECS_KEY, next)
      return next
    })
  }, [])

  // --- Reset ---
  const resetAllData = useCallback(() => {
    setNinjas(MOCK_NINJAS)
    setScrolls(MOCK_SCROLLS)
    setRecommendations(MOCK_RECOMMENDATIONS)
    saveToStorage(NINJAS_KEY, MOCK_NINJAS)
    saveToStorage(SCROLLS_KEY, MOCK_SCROLLS)
    saveToStorage(RECS_KEY, MOCK_RECOMMENDATIONS)
  }, [])

  return (
    <DataContext.Provider
      value={{
        ninjas,
        scrolls,
        recommendations,
        addNinja,
        updateNinja,
        deleteNinja,
        addScroll,
        updateScroll,
        deleteScroll,
        addRecommendation,
        updateRecommendation,
        deleteRecommendation,
        resetAllData,
      }}
    >
      {children}
    </DataContext.Provider>
  )
}

export function useData() {
  const ctx = useContext(DataContext)
  if (!ctx) throw new Error('useData 必须在 DataProvider 内使用')
  return ctx
}
